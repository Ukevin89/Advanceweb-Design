<?php


// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
session_start();
include("db.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $confirm  = trim($_POST["confirm"]);

    // Check if passwords match
    if ($password !== $confirm) {
        $message = "<p class='error'>Passwords do not match!</p>";
    } else {
        // Check if username already exists
        $check = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $check->bind_param("s", $username);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $message = "<p class='error'>Username already taken!</p>";
        } else {
            // Securely hash the password
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user
            $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hashed);
            $stmt->execute();

            if ($stmt) {
                $message = "<p class='success'>Registration successful! <a href='index.php'>Login here</a></p>";
            } else {
                $message = "<p class='error'>Error: Could not register user.</p>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Account</title>
    <style>
        body {
            background: linear-gradient(120deg, #1abc9c, #16a085);
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .register-container {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.2);
            width: 370px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        button {
            background-color: #16a085;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            width: 100%;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #138d75;
        }

        .error {
            color: red;
            margin-top: 15px;
        }

        .success {
            color: green;
            margin-top: 15px;
        }

        .footer {
            margin-top: 25px;
            font-size: 14px;
            color: #777;
        }

        a {
            color: #16a085;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="register-container">
        <h2>Create an Account</h2>
        <form method="POST" action="">
            <input type="text" name="username" placeholder="Choose a username" required>
            <input type="password" name="password" placeholder="Enter password" required>
            <input type="password" name="confirm" placeholder="Confirm password" required>
            <button type="submit">Register</button>
        </form>

        <?php echo $message; ?>

        <div class="footer">
            Already have an account? <a href="index.php">Login here</a>
        </div>
    </div>
</body>
</html>
